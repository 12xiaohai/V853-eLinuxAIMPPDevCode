#ifndef __WMG_GET_CONFIG_H__
#define __WMG_GET_CONFIG_H__

#include "wmg_common.h"

#if __cplusplus
extern "C" {
#endif

int get_config(char *config_name, char *config_buf, char *config_default);

#if __cplusplus
}
#endif

#endif /*  __WMG_GET_CONFIG_H__ */
